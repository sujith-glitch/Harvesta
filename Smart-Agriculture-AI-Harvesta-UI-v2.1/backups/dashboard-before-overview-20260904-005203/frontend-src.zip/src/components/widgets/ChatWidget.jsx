import { useEffect, useRef, useState } from 'react';
import { ArrowUp, Loader2, Mic, MicOff, Volume2, Waves, X } from 'lucide-react';
import { createChatConversation, sendChatMessage } from '../../services/api';
import { usePreferences } from '../../context/PreferencesContext';

export default function ChatWidget() {
  const { preferences, speechLocale, t } = usePreferences();
  const [msg, setMsg] = useState('');
  const [conversationId, setConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef(null);
  const recognitionRef = useRef(null);
  const voiceModeRef = useRef(false);
  const mountedRef = useRef(true);
  const sendingRef = useRef(false);

  useEffect(() => () => {
    mountedRef.current = false;
    voiceModeRef.current = false;
    recognitionRef.current?.abort?.();
    window.speechSynthesis?.cancel?.();
  }, []);

  function stopVoiceMode() {
    voiceModeRef.current = false;
    setVoiceMode(false);
    setIsListening(false);
    setIsSpeaking(false);
    recognitionRef.current?.abort?.();
    window.speechSynthesis?.cancel?.();
  }

  function startListening() {
    if (!voiceModeRef.current || !preferences.voice_enabled || sendingRef.current) return;
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
      setError('Live voice chat is not supported in this browser. Chrome on Android or desktop is recommended.');
      stopVoiceMode();
      return;
    }
    window.speechSynthesis?.cancel?.();
    const recognition = new Recognition();
    recognitionRef.current = recognition;
    recognition.lang = speechLocale;
    recognition.interimResults = true;
    recognition.continuous = false;
    let finalTranscript = '';
    recognition.onstart = () => { if (mountedRef.current) { setIsListening(true); setError(''); } };
    recognition.onresult = (event) => {
      let transcript = '';
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        transcript += event.results[index][0].transcript;
        if (event.results[index].isFinal) finalTranscript += event.results[index][0].transcript;
      }
      setMsg(finalTranscript || transcript);
      if (finalTranscript.trim()) {
        recognition.stop();
        sendMessage(finalTranscript.trim(), true);
      }
    };
    recognition.onerror = (event) => {
      setIsListening(false);
      if (event.error !== 'no-speech' && event.error !== 'aborted') setError('I could not hear that clearly. Please try again or type your question.');
    };
    recognition.onend = () => {
      setIsListening(false);
      if (voiceModeRef.current && !finalTranscript.trim() && !sendingRef.current) window.setTimeout(startListening, 450);
    };
    try { recognition.start(); }
    catch { setError('The microphone is already active. Please wait a moment.'); }
  }

  function speakReply(text, continueVoice) {
    if (!preferences.voice_auto_speak || !('speechSynthesis' in window)) {
      if (continueVoice && voiceModeRef.current) window.setTimeout(startListening, 300);
      return;
    }
    const spokenText = text.replace(/[*_#`>-]/g, ' ').replace(/\s+/g, ' ').trim();
    const utterance = new SpeechSynthesisUtterance(spokenText);
    utterance.lang = speechLocale;
    utterance.rate = 0.98;
    const voices = window.speechSynthesis.getVoices();
    utterance.voice = voices.find((voice) => voice.lang.toLowerCase().startsWith(speechLocale.slice(0, 2).toLowerCase())) || null;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => { setIsSpeaking(false); if (continueVoice && voiceModeRef.current) window.setTimeout(startListening, 350); };
    utterance.onerror = () => { setIsSpeaking(false); if (continueVoice && voiceModeRef.current) window.setTimeout(startListening, 350); };
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  async function sendMessage(overrideText = '', fromVoice = false) {
    const clean = (overrideText || msg).trim();
    if (!clean || sendingRef.current) return;
    recognitionRef.current?.stop?.();
    setMsg(''); setError(''); setIsSending(true); setIsListening(false); sendingRef.current = true;
    setMessages((current) => [...current, { id: `local-${Date.now()}`, role: 'user', content: clean }]);
    try {
      let activeId = conversationId;
      if (!activeId) {
        const conversation = await createChatConversation({ title: clean.slice(0, 45) });
        activeId = conversation.id; setConversationId(activeId);
      }
      const result = await sendChatMessage(activeId, clean);
      setMessages((current) => [...current, result.assistant_message]);
      speakReply(result.assistant_message.content, fromVoice);
    } catch (err) {
      setError(err.message || 'The assistant could not respond. Please try again.');
      if (fromVoice && voiceModeRef.current) window.setTimeout(startListening, 600);
    } finally {
      sendingRef.current = false; setIsSending(false); inputRef.current?.focus();
    }
  }

  function startVoiceMode() {
    if (!preferences.voice_enabled) { setError('Voice conversations are turned off in Settings.'); return; }
    voiceModeRef.current = true; setVoiceMode(true); setError(''); window.setTimeout(startListening, 100);
  }

  const closeChat = () => { stopVoiceMode(); setMessages([]); setError(''); };

  return (
    <>
      {(messages.length > 0 || isSending || error || voiceMode) && (
        <section className="chat-response-popover" aria-label="Harvesta AI response" aria-live="polite">
          <div className="chat-response-header"><strong>Harvesta AI</strong><button type="button" onClick={closeChat} aria-label="Close chat response"><X size={16} /></button></div>
          {voiceMode && <div className={`live-voice-state ${isListening ? 'listening' : ''} ${isSpeaking ? 'speaking' : ''}`}>
            <span className="voice-orb">{isListening ? <Waves size={25} /> : isSpeaking ? <Volume2 size={25} /> : <Loader2 size={23} className="animate-spin" />}</span>
            <div><strong>{isListening ? t('voiceListening') : isSpeaking ? t('voiceSpeaking') : t('preparingAnswer')}</strong><small>Speak naturally in {speechLocale.split('-')[0].toUpperCase()}</small></div>
            <button type="button" onClick={stopVoiceMode}><MicOff size={15} />{t('endVoice')}</button>
          </div>}
          <div className="chat-response-messages">
            {messages.slice(-6).map((message) => <div key={message.id} className={`chat-response-message ${message.role === 'user' ? 'user' : 'assistant'}`}>{message.content}</div>)}
            {isSending && <div className="chat-response-message assistant chat-thinking"><Loader2 size={13} className="animate-spin" />{t('preparingAnswer')}</div>}
            {error && <div className="chat-response-error">{error}</div>}
          </div>
          <p>{t('aiDisclaimer')}</p>
        </section>
      )}
      <div className="chat-widget" role="search" aria-label="Ask AI assistant">
        <input ref={inputRef} type="text" className="chat-widget-input" placeholder={t('askPlaceholder')} value={msg} onChange={(event) => setMsg(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); sendMessage(); } }} maxLength={2000} disabled={isSending || voiceMode} />
        {preferences.voice_enabled && <button type="button" className={`chat-mic ${voiceMode ? 'active' : ''}`} aria-label={voiceMode ? t('endVoice') : t('startVoice')} onClick={voiceMode ? stopVoiceMode : startVoiceMode} disabled={isSending && !voiceMode}>{voiceMode ? <MicOff size={16} /> : <Mic size={16} />}</button>}
        <button type="button" className="chat-send" aria-label="Send" onClick={() => sendMessage()} disabled={!msg.trim() || isSending || voiceMode}>{isSending ? <Loader2 size={16} className="animate-spin" /> : <ArrowUp size={16} />}</button>
      </div>
    </>
  );
}
