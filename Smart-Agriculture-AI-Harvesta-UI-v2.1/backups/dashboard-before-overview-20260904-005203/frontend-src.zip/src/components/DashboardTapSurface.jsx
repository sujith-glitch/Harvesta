import { useState } from 'react';
import PropTypes from 'prop-types';

export default function DashboardTapSurface({ children }) {
  const [marker, setMarker] = useState(null);

  const showMarker = (event) => {
    // Ignore keyboard-generated clicks; taps still work without blocking scrolling.
    if (event.detail === 0 || event.button !== 0) return;

    const bounds = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    if (x < 0 || y < 0 || x > bounds.width || y > bounds.height) return;

    setMarker((previous) => ({ x, y, sequence: (previous?.sequence ?? 0) + 1 }));
  };

  return (
    <div className="dashboard-tap-surface" onClickCapture={showMarker}>
      {children}
      <div className="dashboard-tap-overlay" aria-hidden="true">
        {marker && (
          <span
            key={marker.sequence}
            className="map-marker dashboard-tap-marker"
            style={{ left: marker.x, top: marker.y }}
          />
        )}
      </div>
    </div>
  );
}

DashboardTapSurface.propTypes = {
  children: PropTypes.node.isRequired,
};
