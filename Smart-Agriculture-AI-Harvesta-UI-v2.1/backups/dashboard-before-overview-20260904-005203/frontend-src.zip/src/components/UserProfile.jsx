import PropTypes from 'prop-types';
import { LogOut } from 'lucide-react';

export function UserProfile({ user, onLogout }) {
  if (!user) return null;

  const initial = (user.full_name || user.email || 'F').charAt(0).toUpperCase();

  return (
    <div className="flex items-center gap-3 p-2 pr-3 rounded-2xl bg-white/80 backdrop-blur-sm border border-black/5 shadow-soft">
      <div
        className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm"
        style={{
          background: 'linear-gradient(135deg, var(--c-lime) 0%, var(--c-lime-deep) 100%)',
          color: 'var(--c-ink-900)',
        }}
      >
        {initial}
      </div>
      <div className="flex flex-col leading-tight pr-1">
        <span className="text-[13px] font-semibold text-ink-900 truncate max-w-[140px]">
          {user.full_name || 'Farmer Account'}
        </span>
        <span className="text-[11px] text-ink-500 truncate max-w-[140px]">
          {user.email}
        </span>
      </div>
      <button
        type="button"
        onClick={onLogout}
        title="Sign out"
        aria-label="Sign out"
        className="w-9 h-9 rounded-xl flex items-center justify-center text-ink-500 hover:text-red-600 hover:bg-red-50 transition-colors"
      >
        <LogOut size={16} />
      </button>
    </div>
  );
}

UserProfile.propTypes = {
  user: PropTypes.shape({
    email: PropTypes.string,
    full_name: PropTypes.string,
  }),
  onLogout: PropTypes.func.isRequired,
};

export default UserProfile;
