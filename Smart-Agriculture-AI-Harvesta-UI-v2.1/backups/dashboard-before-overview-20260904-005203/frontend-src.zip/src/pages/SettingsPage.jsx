import { useEffect, useState } from 'react';
import { Bell, CheckCircle2, Languages, LayoutPanelTop, Loader2, Moon, Palette, Save, Sparkles, Sun, Volume2 } from 'lucide-react';
import { getAppPreferences, updateAppPreferences } from '../services/api';
import { LANGUAGES, usePreferences } from '../context/PreferencesContext';

function Toggle({ checked, onChange, label, description }) {
  return (
    <label className="setting-toggle-row">
      <span>
        <strong>{label}</strong>
        {description && <small>{description}</small>}
      </span>
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <span className="harvesta-switch" aria-hidden="true" />
    </label>
  );
}

export default function SettingsPage({ onNavigate }) {
  const { preferences, updateLocalPreferences, t } = usePreferences();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    getAppPreferences()
      .then((data) => active && updateLocalPreferences(data))
      .catch((err) => active && setError(err.message || 'Could not load settings.'))
      .finally(() => active && setIsLoading(false));
    return () => { active = false; };
  }, [updateLocalPreferences]);

  const change = (key, value) => {
    updateLocalPreferences({ [key]: value });
    setMessage('');
  };

  const save = async () => {
    setIsSaving(true);
    setError('');
    try {
      const saved = await updateAppPreferences({
        language: preferences.language,
        theme: preferences.theme,
        compact_mode: preferences.compact_mode,
        reduce_motion: preferences.reduce_motion,
        voice_enabled: preferences.voice_enabled,
        voice_auto_speak: preferences.voice_auto_speak,
      });
      updateLocalPreferences(saved);
      setMessage(t('saved'));
    } catch (err) {
      setError(err.message || 'Could not save settings.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="page-shell utility-page">
      <header className="utility-header">
        <div>
          <span className="eyebrow-text">{t('preferences')}</span>
          <h1><Palette size={26} /> {t('settings')}</h1>
          <p>{t('settingsIntro')}</p>
        </div>
        <button type="button" className="btn-primary" onClick={save} disabled={isSaving || isLoading}>
          {isSaving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
          {isSaving ? t('saving') : t('saveChanges')}
        </button>
      </header>

      {message && <div className="status-banner success"><CheckCircle2 size={17} />{message}</div>}
      {error && <div className="status-banner error">{error}</div>}

      {isLoading ? (
        <div className="analytic-card utility-loading"><Loader2 className="animate-spin" /> {t('loadingSettings')}</div>
      ) : (
        <div className="settings-grid">
          <section className="analytic-card settings-section settings-section-wide">
            <div className="section-heading"><Languages size={20} /><div><h2>{t('language')}</h2><p>{t('languageDesc')}</p></div></div>
            <div className="language-grid">
              {LANGUAGES.map((language) => (
                <button
                  type="button"
                  key={language.code}
                  className={`language-option ${preferences.language === language.code ? 'selected' : ''}`}
                  onClick={() => change('language', language.code)}
                >
                  <span>{language.nativeLabel}</span><small>{language.label}</small>
                </button>
              ))}
            </div>
          </section>

          <section className="analytic-card settings-section">
            <div className="section-heading"><Sun size={20} /><div><h2>{t('appearance')}</h2><p>{t('appearanceDesc')}</p></div></div>
            <div className="segmented-choice">
              {[
                ['light', t('light'), Sun], ['dark', t('dark'), Moon], ['system', t('system'), Sparkles],
              ].map(([value, label, Icon]) => (
                <button type="button" key={value} className={preferences.theme === value ? 'active' : ''} onClick={() => change('theme', value)}>
                  <Icon size={16} />{label}
                </button>
              ))}
            </div>
            <Toggle checked={preferences.compact_mode} onChange={(value) => change('compact_mode', value)} label={t('compactLayout')} description={t('compactDesc')} />
            <Toggle checked={preferences.reduce_motion} onChange={(value) => change('reduce_motion', value)} label={t('reduceMotion')} description={t('reduceMotionDesc')} />
          </section>

          <section className="analytic-card settings-section">
            <div className="section-heading"><Volume2 size={20} /><div><h2>{t('voiceAssistant')}</h2><p>{t('voiceDesc')}</p></div></div>
            <Toggle checked={preferences.voice_enabled} onChange={(value) => change('voice_enabled', value)} label={t('enableVoice')} />
            <Toggle checked={preferences.voice_auto_speak} onChange={(value) => change('voice_auto_speak', value)} label={t('autoSpeak')} />
          </section>

          <section className="analytic-card settings-section settings-link-card">
            <div className="section-heading"><Bell size={20} /><div><h2>{t('notificationSettings')}</h2><p>{t('alertEmailDesc')}</p></div></div>
            <button type="button" className="btn-secondary" onClick={() => onNavigate('notification-settings')}>{t('openNotificationSettings')}</button>
          </section>

          <section className="analytic-card settings-section settings-link-card">
            <div className="section-heading"><LayoutPanelTop size={20} /><div><h2>{t('accountProfile')}</h2><p>{t('accountProfileDesc')}</p></div></div>
            <button type="button" className="btn-secondary" onClick={() => onNavigate('profile')}>{t('profile')}</button>
          </section>
        </div>
      )}
    </div>
  );
}
