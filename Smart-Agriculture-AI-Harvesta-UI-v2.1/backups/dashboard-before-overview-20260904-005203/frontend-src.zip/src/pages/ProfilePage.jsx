import { useEffect, useState } from 'react';
import { BadgeCheck, CalendarDays, Loader2, Mail, MapPin, Save, ShieldCheck, UserRound } from 'lucide-react';
import { getProfile, updateProfile } from '../services/api';
import { usePreferences } from '../context/PreferencesContext';

const EMPTY = {
  full_name: '', phone: '', address: '', district: '', state: '', country: '', bio: '',
  primary_crop: '', experience_years: '', avatar_color: '#A6BC12',
};

export default function ProfilePage({ user, onProfileUpdated }) {
  const { t } = usePreferences();
  const [profile, setProfile] = useState({ ...EMPTY, full_name: user?.full_name || '' });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    getProfile()
      .then((data) => setProfile({ ...EMPTY, ...data, experience_years: data.experience_years ?? '' }))
      .catch((err) => setError(err.message || 'Could not load profile.'))
      .finally(() => setIsLoading(false));
  }, []);

  const set = (key) => (event) => setProfile((current) => ({ ...current, [key]: event.target.value }));
  const save = async (event) => {
    event.preventDefault();
    setIsSaving(true); setMessage(''); setError('');
    try {
      const saved = await updateProfile({
        full_name: profile.full_name,
        phone: profile.phone || null, address: profile.address || null, district: profile.district || null,
        state: profile.state || null, country: profile.country || null, bio: profile.bio || null,
        primary_crop: profile.primary_crop || null,
        experience_years: profile.experience_years === '' ? null : Number(profile.experience_years),
        avatar_color: profile.avatar_color,
      });
      setProfile({ ...EMPTY, ...saved, experience_years: saved.experience_years ?? '' });
      onProfileUpdated?.(saved);
      setMessage(t('saved'));
    } catch (err) {
      setError(err.message || 'Could not save profile.');
    } finally { setIsSaving(false); }
  };

  const initials = (profile.full_name || profile.email || 'F').split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="page-shell utility-page">
      <header className="utility-header">
        <div><span className="eyebrow-text">{t('profile')}</span><h1><UserRound size={26} /> {t('profileTitle')}</h1><p>{t('profileIntro')}</p></div>
      </header>
      {message && <div className="status-banner success"><BadgeCheck size={17} />{message}</div>}
      {error && <div className="status-banner error">{error}</div>}
      {isLoading ? <div className="analytic-card utility-loading"><Loader2 className="animate-spin" /> {t('loadingProfile')}</div> : (
        <form onSubmit={save} className="profile-layout">
          <aside className="analytic-card profile-summary">
            <div className="profile-avatar-large" style={{ background: profile.avatar_color }}>{initials}</div>
            <h2>{profile.full_name}</h2><p>{profile.email}</p>
            <div className="profile-fact"><BadgeCheck size={16} /><span><strong>{t('verified')}</strong><small>Gmail verified</small></span></div>
            <div className="profile-fact"><ShieldCheck size={16} /><span><strong>{t('accountRole')}</strong><small>{profile.role === 'admin' ? t('admin') : t('farmer')}</small></span></div>
            <div className="profile-fact"><CalendarDays size={16} /><span><strong>{t('memberSince')}</strong><small>{profile.member_since ? new Date(profile.member_since).toLocaleDateString() : '—'}</small></span></div>
            <label className="avatar-colour"><span>{t('profileColour')}</span><input type="color" value={profile.avatar_color} onChange={set('avatar_color')} /></label>
          </aside>
          <section className="analytic-card profile-form-card">
            <div className="profile-form-grid">
              <label><span>{t('fullName')}</span><input className="harvesta-input" value={profile.full_name} onChange={set('full_name')} required minLength={2} /></label>
              <label><span>{t('email')}</span><div className="input-with-icon"><Mail size={16} /><input className="harvesta-input" value={profile.email || ''} disabled /></div></label>
              <label><span>{t('phone')}</span><input className="harvesta-input" value={profile.phone} onChange={set('phone')} placeholder="+91 …" /></label>
              <label><span>{t('primaryCrop')}</span><input className="harvesta-input" value={profile.primary_crop} onChange={set('primary_crop')} placeholder="e.g. Tomato" /></label>
              <label><span>{t('experience')}</span><input className="harvesta-input" type="number" min="0" max="100" value={profile.experience_years} onChange={set('experience_years')} /></label>
              <label><span>{t('district')}</span><input className="harvesta-input" value={profile.district} onChange={set('district')} /></label>
              <label><span>{t('state')}</span><input className="harvesta-input" value={profile.state} onChange={set('state')} /></label>
              <label><span>{t('country')}</span><input className="harvesta-input" value={profile.country} onChange={set('country')} placeholder="India" /></label>
              <label className="span-all"><span>{t('address')}</span><div className="input-with-icon"><MapPin size={16} /><input className="harvesta-input" value={profile.address} onChange={set('address')} /></div></label>
              <label className="span-all"><span>{t('bio')}</span><textarea className="harvesta-input" rows="4" value={profile.bio} onChange={set('bio')} placeholder={t('profileBioHint')} /></label>
            </div>
            <div className="form-actions"><button type="submit" className="btn-primary" disabled={isSaving}>{isSaving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{isSaving ? t('saving') : t('saveChanges')}</button></div>
          </section>
        </form>
      )}
    </div>
  );
}
